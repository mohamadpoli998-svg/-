package com.amiri.pelvicfloor;

import android.app.*;import android.os.*;import android.content.*;import android.graphics.Color;import android.graphics.Typeface;import android.view.*;import android.widget.*;import java.text.SimpleDateFormat;import java.util.*;

public class MainActivity extends Activity {
    LinearLayout content; SharedPreferences prefs; CountDownTimer timer; TextView timerText; Button timerBtn; int selected=0;
    final String[] names={"تنفس و رهاسازی","کگل آهسته","کگل سریع","پل باسن","Bird-Dog","نشستن و بلندشدن از صندلی"};
    final int[] secs={60,60,60,120,120,90};
    final String[] reps={"۱ دقیقه","هفته ۱: ۵×۳ ثانیه؛ هفته‌های بعد تدریجی بیشتر","۵ تا ۱۰ تکرار","۲×۱۰ تکرار","۲×۶ تا ۸ هر طرف","۲×۸ تا ۱۰ تکرار"};
    final String[] how={
      "آرام بنشین یا دراز بکش. چند نفس آرام بکش و هنگام بازدم بدن را رها کن.",
      "عضلات کف لگن را آرام منقبض کن، مدت برنامه نگه دار و کاملاً رها کن. نفس را حبس نکن و شکم، باسن و ران‌ها را تا حد امکان آرام نگه دار.",
      "انقباض کوتاه و ملایم انجام بده و بعد کاملاً رها کن. بین تکرارها عجله نکن.",
      "به پشت دراز بکش، زانوها خم و کف پاها روی زمین. لگن را آرام بالا ببر و کنترل‌شده پایین بیاور.",
      "چهاردست‌وپا باش. یک دست و پای مخالف را آرام دراز کن، چند ثانیه کنترل کن و برگرد؛ سپس سمت دیگر.",
      "روی صندلی محکم بنشین. با فشار آرام پاها بلند شو و دوباره کنترل‌شده بنشین."
    };
    final String[] tips={"هدف این مرحله آرام‌سازی است.","کیفیت مهم‌تر از تعداد است؛ اگر درد داشتی ادامه نده.","اگر خسته شدی استراحت کن.","کمر را بیش از حد گود نکن.","حرکت باید آرام و کنترل‌شده باشد.","در صورت درد زانو یا لگن، حرکت را متوقف کن و با متخصص مشورت کن."};

    @Override public void onCreate(Bundle b){super.onCreate(b); prefs=getSharedPreferences("amiri_progress",MODE_PRIVATE); showHome();}
    TextView tv(String s,int size){TextView v=new TextView(this);v.setText(s);v.setTextSize(size);v.setTextColor(Color.rgb(25,48,64));v.setPadding(18,16,18,16);return v;}
    Button btn(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextSize(15);return b;}
    void base(String title){
      LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.rgb(246,248,249));
      TextView head=tv(title+"\nتمرین‌کننده: آقای امیری",21);head.setTextColor(Color.WHITE);head.setTypeface(Typeface.DEFAULT,Typeface.BOLD);head.setBackgroundColor(Color.rgb(15,52,72));head.setPadding(22,24,22,20);root.addView(head);
      ScrollView sc=new ScrollView(this);content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(16,12,16,18);sc.addView(content);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
      LinearLayout nav=new LinearLayout(this);String[] ns={"خانه","تمرین","آموزش","پیشرفت"};for(String n:ns){Button b=btn(n);b.setTextSize(13);if(n.equals("خانه"))b.setOnClickListener(v->showHome());if(n.equals("تمرین"))b.setOnClickListener(v->showTrain());if(n.equals("آموزش"))b.setOnClickListener(v->showLearn());if(n.equals("پیشرفت"))b.setOnClickListener(v->showProgress());nav.addView(b,new LinearLayout.LayoutParams(0,-2,1));}root.addView(nav);setContentView(root);
    }
    void card(String title,String body){TextView v=tv(title+"\n"+body,16);v.setBackgroundColor(Color.WHITE);v.setPadding(18,18,18,18);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,6,0,6);content.addView(v,p);}
    int done(){return prefs.getInt("done",0);}
    int week(){return Math.min(4,done()/7+1);}
    String today(){return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());}
    boolean completedToday(){return prefs.getBoolean("day_"+today(),false);}
    void showHome(){base("برنامه تقویت کف لگن");int d=done();card("سلام آقای امیری 👋","این نسخه آفلاین است و برای برنامه ۴ هفته‌ای طراحی شده است.\n\nپیشرفت: "+d+" از ۲۸ روز");
      card("برنامه امروز - هفته "+week(),planForWeek(week()));Button b=btn(completedToday()?"امروز ثبت شده ✅":"شروع تمرین امروز");b.setOnClickListener(v->showTrain());content.addView(b);Button p=btn("مشاهده پیشرفت");p.setOnClickListener(v->showProgress());content.addView(p);card("نکات مهم","کگل را هنگام ادرار کردن تمرین نکن. نفس را حبس نکن. در صورت درد یا بدتر شدن علائم تمرین را متوقف کن و با پزشک یا فیزیوتراپیست کف لگن مشورت کن.");}
    String planForWeek(int w){String slow=w==1?"۵×۳ ثانیه":w==2?"۸×۴ ثانیه":w==3?"۱۰×۵ ثانیه":"۱۰×۷–۸ ثانیه";String quick=w==1?"۵ تکرار":w==2?"۸ تکرار":"۱۰ تکرار";return "• تنفس و رهاسازی — ۱ دقیقه\n• کگل آهسته — "+slow+"\n• کگل سریع — "+quick+"\n• پل باسن — ۲×۱۰\n• Bird-Dog — ۲×۶–۸ هر طرف\n• نشستن و بلندشدن — ۲×۸–۱۰\n\nروز استراحت: یک روز در هفته.";}
    void showLearn(){base("آموزش کامل حرکات");for(int i=0;i<names.length;i++)card((i+1)+". "+names[i],"مدت/تکرار: "+reps[i]+"\n\nروش انجام:\n"+how[i]+"\n\nنکته:\n"+tips[i]);}
    void showTrain(){base("تمرین امروز");Spinner sp=new Spinner(this);sp.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,names));content.addView(sp);TextView info=tv("",16);info.setBackgroundColor(Color.WHITE);content.addView(info);timerText=tv("01:00",40);timerText.setGravity(Gravity.CENTER);content.addView(timerText);timerBtn=btn("شروع تایمر");content.addView(timerBtn);Button doneBtn=btn(completedToday()?"امروز قبلاً ثبت شده ✅":"تمرین امروز را کامل کردم ✅");content.addView(doneBtn);
      sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){public void onNothingSelected(AdapterView<?>p){}public void onItemSelected(AdapterView<?>p,View v,int pos,long id){selected=pos;info.setText(names[pos]+"\n\nمدت/تکرار: "+reps[pos]+"\n\nروش انجام:\n"+how[pos]+"\n\nنکته: "+tips[pos]);if(timer==null)timerText.setText(fmt(secs[pos]));}});
      timerBtn.setOnClickListener(v->startTimer(secs[selected]));doneBtn.setOnClickListener(v->markToday());}
    String fmt(long s){return String.format(Locale.US,"%02d:%02d",s/60,s%60);}
    void startTimer(int s){if(timer!=null)timer.cancel();timerBtn.setEnabled(false);timer=new CountDownTimer(s*1000L,1000){public void onTick(long ms){timerText.setText(fmt((ms+999)/1000));}public void onFinish(){timerText.setText("00:00");timerBtn.setEnabled(true);Toast.makeText(MainActivity.this,"مرحله تمام شد ✅",Toast.LENGTH_SHORT).show();}};timer.start();}
    void markToday(){if(completedToday()){Toast.makeText(this,"امروز قبلاً ثبت شده است.",Toast.LENGTH_SHORT).show();return;}int d=done();if(d<28){prefs.edit().putInt("done",d+1).putBoolean("day_"+today(),true).apply();Toast.makeText(this,"روز امروز ثبت شد 🌱",Toast.LENGTH_SHORT).show();showHome();}else Toast.makeText(this,"برنامه ۲۸ روزه کامل شده است 🎉",Toast.LENGTH_SHORT).show();}
    void showProgress(){base("پیشرفت آقای امیری");int d=done();int pct=Math.round(d*100f/28);card("پیشرفت کلی",d+" از ۲۸ روز کامل شده\nپیشرفت: "+pct+"٪\nهفته فعلی: "+week()+" از ۴");for(int w=1;w<=4;w++){int n=Math.max(0,Math.min(7,d-(w-1)*7));card("هفته "+w,n==7?"۷ از ۷ — کامل شد ✅":n+" از ۷ روز");}
      card("وضعیت امروز",completedToday()?"امروز انجام شده و ثبت شده ✅":"امروز هنوز ثبت نشده است.");Button reset=btn("بازنشانی کامل پیشرفت");reset.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("بازنشانی پیشرفت؟").setMessage("تمام روزهای ثبت‌شده حذف می‌شوند.").setNegativeButton("لغو",null).setPositiveButton("بازنشانی",(d1,w)->{prefs.edit().clear().apply();showProgress();}).show());content.addView(reset);}
    @Override protected void onDestroy(){if(timer!=null)timer.cancel();super.onDestroy();}
}
